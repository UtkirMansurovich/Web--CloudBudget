const btn  = document.getElementById('btn')
const overlay = document.querySelector('.overlay')
const modal = document.querySelector('.modal')
btn.addEventListener('click', function(){
    overlay.classList.remove('d-none')
    modal.classList.add('showModal')
})